﻿using ReceitasApp.Models;
using SQLite;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Storage;

namespace ReceitasApp.Models
{
    public class Database
    {
        public static SQLiteConnection Conexao()
        {
            var con = new SQLite.SQLiteConnection(
                Path.Combine(ApplicationData.Current.LocalFolder.Path,
                "ReceitasApp.db"), true);

            return con;
        }

        public static void CriarBase()
        {
            using (var conexao = Conexao())
            {
                conexao.CreateTable<UnidadeMedida>();
                //conexao.CreateTable<Receita>();


                conexao.Close();
            }
        }

        #region UnidadeMedida

        public static void InserirUnidadeMedida(UnidadeMedida unidadeMedida)
        {
            using (var conexao = Database.Conexao())
            {
                conexao.Insert(unidadeMedida);
                conexao.Close();
            }
        }

        public static List<UnidadeMedida> ListarUnidadeMedida()
        {
            using (var conexao = Database.Conexao())
            {
                List<UnidadeMedida> lista =
                    conexao.Query<UnidadeMedida>("SELECT * FROM UnidadeMedida");
                conexao.Close();
                return lista;
            }
        }

        public static void ExcluirUnidadeMedida(UnidadeMedida unidadeMedida)
        {
            using (var conexao = Database.Conexao())
            {
                conexao.Delete(unidadeMedida);
                conexao.Close();
            }
        }

        public static UnidadeMedida BuscarUnidadeMedidaPorId(int id)
        {
            using (var conexao = Database.Conexao())
            {
                UnidadeMedida unidadeMedida = conexao.Query<UnidadeMedida>("SELECT * FROM UnidadeMedida WHERE UnidadeMedidaID = " + id.ToString()).FirstOrDefault();
                conexao.Close();
                return unidadeMedida;
            }
        }

        public static UnidadeMedida AtualizarUnidadeMedida(int id, string nome)
        {
            using (var conexao = Database.Conexao())
            {
                UnidadeMedida unidadeMedida = BuscarUnidadeMedidaPorId(id);
                unidadeMedida.Nome = nome;
                conexao.Update(unidadeMedida);
                conexao.Close();
                return unidadeMedida;
            }
        }

        #endregion
    }
}
