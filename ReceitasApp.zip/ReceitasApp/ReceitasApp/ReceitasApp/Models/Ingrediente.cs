﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReceitasApp.Models
{
    public class Ingrediente
    {
        public int IngredienteID { get; set; }
        public String Nome { get; set; }
    }
}
